//
//
//	/*
//	 *	This content is generated from the API File Info.
//	 *	(Alt+Shift+Ctrl+I).
//	 *
//	 *	@desc
//	 *	@file 		iphone_14___3
//	 *	@date 		Wednesday 08th of February 2023 08:47:32 AM
//	 *	@title 		Page 1
//	 *	@author
//	 *	@keywords
//	 *	@generator 	Export Kit v1.3.figma
//	 *
//	 */
//
//
//package com.example.iphone2;
//
//import android.app.Activity;
//import android.os.Bundle;
//
//
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.example.iphone2.R;
//
//	public class iphone_14___3_activity extends Activity {
//
//
//	private View _bg__iphone_14___3_ek2;
//	private View rectangle_10;
//	private ImageView logo_1;
//	private ImageView upperlogo_1;
//	private View rectangle_11;
//	private ImageView vector;
//	private TextView username;
//	private View rectangle_12;
//	private TextView password;
//	private ImageView vector_ek1;
//	private TextView full_name;
//	private View rectangle_14;
//	private TextView how_many_properties_do_you_manage_;
//	private View rectangle_15;
//	private TextView email;
//	private View rectangle_16;
//	private TextView phone_number;
//	private View rec;
//	private ImageView vector_ek2;
//	private ImageView polygon_2;
//	private ImageView polygon_1;
//	private ImageView polygon_3;
//	private TextView sign_up;
//	private ImageView vector_ek3;
//	private TextView you_have_no_accounts__sign_in;
//
//	@Override
//	public void onCreate(Bundle savedInstanceState) {
//
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.iphone_14___3);
//
//
//		_bg__iphone_14___3_ek2 = (View) findViewById(R.id._bg__iphone_14___3_ek2);
//		rectangle_10 = (View) findViewById(R.id.rectangle_10);
//		logo_1 = (ImageView) findViewById(R.id.logo_1);
//		upperlogo_1 = (ImageView) findViewById(R.id.upperlogo_1);
//		rectangle_11 = (View) findViewById(R.id.rectangle_11);
//		vector = (ImageView) findViewById(R.id.vector);
//		username = (TextView) findViewById(R.id.username);
//		rectangle_12 = (View) findViewById(R.id.rectangle_12);
//		password = (TextView) findViewById(R.id.password1);
//		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
//		full_name = (TextView) findViewById(R.id.full_name);
//		rectangle_14 = (View) findViewById(R.id.rectangle_14);
//		how_many_properties_do_you_manage_ = (TextView) findViewById(R.id.how_many_properties_do_you_manage_);
//		rectangle_15 = (View) findViewById(R.id.rectangle_15);
//		email = (TextView) findViewById(R.id.email);
//		rectangle_16 = (View) findViewById(R.id.rectangle_16);
//		phone_number = (TextView) findViewById(R.id.phone_number);
//		rec = (View) findViewById(R.id.rec);
//		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
//		polygon_2 = (ImageView) findViewById(R.id.polygon_2);
//		polygon_1 = (ImageView) findViewById(R.id.polygon_1);
//		polygon_3 = (ImageView) findViewById(R.id.polygon_3);
//		sign_up = (TextView) findViewById(R.id.sign_up);
//		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
//		you_have_no_accounts__sign_in = (TextView) findViewById(R.id.you_have_no_accounts__sign_in);
//
//
//		//custom code goes here
//
//	}
//}
//
//